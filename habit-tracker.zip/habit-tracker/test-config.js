// test-connection.js
const cassandra = require('cassandra-driver');
require('dotenv').config(); 
const client = new cassandra.Client({
    contactPoints: process.env.CASSANDRA_CONTACT_POINTS.split(','),
    localDataCenter: process.env.CASSANDRA_DC,
    keyspace: process.env.CASSANDRA_KEYSPACE
  });

client.connect()
  .then(() => {
    console.log('Successfully connected to Cassandra!');
    return client.execute('SELECT * FROM system.local');
  })
  .then(result => {
    console.log('Cluster information:', result.rows[0]);
    client.shutdown();
  })
  .catch(err => {
    console.error('Connection failed:', err);
    client.shutdown();
  });