// scripts/cassandra-setup.js
const { Client } = require('cassandra-driver');
require('dotenv').config();

async function setupCassandra() {
  const client = new Client({
    contactPoints: process.env.CASSANDRA_CONTACT_POINTS.split(','),
    localDataCenter: process.env.CASSANDRA_DC,
    keyspace: process.env.CASSANDRA_KEYSPACE
  });

  try {
    await client.connect();
    console.log('Connected to Cassandra');

    // Create users table
    await client.execute(`
      CREATE TABLE IF NOT EXISTS users (
        user_id uuid PRIMARY KEY,
        username text,
        email text,
        password text,
        created_at timestamp
      );
    `);
    console.log('Users table created');

    // Create users_by_email table (for email lookups)
    await client.execute(`
      CREATE TABLE IF NOT EXISTS users_by_email (
        email text PRIMARY KEY,
        user_id uuid
      );
    `);
    console.log('Users_by_email table created');

    // Create habits table
    await client.execute(`
      CREATE TABLE IF NOT EXISTS habits (
        habit_id uuid,
        user_id uuid,
        name text,
        frequency text,
        created_at timestamp,
        PRIMARY KEY (user_id, habit_id)
      );
    `);
    console.log('Habits table created');

    await client.shutdown();
    console.log('Cassandra setup complete');
  } catch (err) {
    console.error('Error setting up Cassandra:', err);
    await client.shutdown();
  }
}

async function addMissingColumns() {
  const client = new Client({
    contactPoints: process.env.CASSANDRA_CONTACT_POINTS.split(','),
    localDataCenter: process.env.CASSANDRA_DC,
    keyspace: process.env.CASSANDRA_KEYSPACE
  });

  try {
    await client.connect();
    console.log('Connected to Cassandra for schema verification');
    
    // Get the actual keyspace name from environment
    const keyspace = process.env.CASSANDRA_KEYSPACE;
    console.log(`Using keyspace: ${keyspace}`);
    
    // First check if the users table exists
    const tableResult = await client.execute(`
      SELECT table_name FROM system_schema.tables 
      WHERE keyspace_name = ? AND table_name = ?
    `, [keyspace, 'users'], { prepare: true });
    
    if (tableResult.rowLength === 0) {
      console.log('Users table does not exist. Please run the main setup first.');
      await client.shutdown();
      return;
    }
    
    // Check if username column exists
    console.log('Checking for username column in users table...');
    const result = await client.execute(`
      SELECT column_name FROM system_schema.columns 
      WHERE keyspace_name = ? AND table_name = ? AND column_name = ?
    `, [keyspace, 'users', 'username'], { prepare: true });
    
    // If username column doesn't exist, add it
    if (result.rowLength === 0) {
      console.log('Username column not found. Adding missing username column to users table...');
      try {
        await client.execute(`ALTER TABLE ${keyspace}.users ADD username text;`, [], { prepare: true });
        console.log('Username column added successfully');
      } catch (alterErr) {
        console.error('Error adding username column:', alterErr);
        console.log('Attempting alternative approach...');
        
        // Try with quotes around identifiers
        try {
          await client.execute(`ALTER TABLE "${keyspace}"."users" ADD "username" text;`, [], { prepare: true });
          console.log('Username column added successfully with quoted identifiers');
        } catch (altErr2) {
          console.error('Alternative approach also failed:', altErr2);
        }
      }
    } else {
      console.log('Username column already exists in users table');
    }
    
    await client.shutdown();
    console.log('Schema verification complete');
  } catch (err) {
    console.error('Error during schema verification:', err);
    try {
      await client.shutdown();
    } catch (shutdownErr) {
      console.error('Error during client shutdown:', shutdownErr);
    }
  }
}

async function inspectSchema() {
  const client = new Client({
    contactPoints: process.env.CASSANDRA_CONTACT_POINTS.split(','),
    localDataCenter: process.env.CASSANDRA_DC,
    keyspace: process.env.CASSANDRA_KEYSPACE
  });

  try {
    await client.connect();
    console.log('Connected to Cassandra for schema inspection');
    
    const keyspace = process.env.CASSANDRA_KEYSPACE;
    
    // Get all tables in the keyspace
    const tablesResult = await client.execute(`
      SELECT table_name FROM system_schema.tables WHERE keyspace_name = ?
    `, [keyspace], { prepare: true });
    
    console.log(`Tables in keyspace ${keyspace}:`);
    for (const row of tablesResult.rows) {
      console.log(`- ${row.table_name}`);
      
      // For each table, get its columns
      const columnsResult = await client.execute(`
        SELECT column_name, type FROM system_schema.columns 
        WHERE keyspace_name = ? AND table_name = ?
      `, [keyspace, row.table_name], { prepare: true });
      
      console.log(`  Columns in ${row.table_name}:`);
      for (const col of columnsResult.rows) {
        console.log(`  - ${col.column_name} (${col.type})`);
      }
    }
    
    await client.shutdown();
    console.log('Schema inspection complete');
  } catch (err) {
    console.error('Error during schema inspection:', err);
    try {
      await client.shutdown();
    } catch (shutdownErr) {
      console.error('Error during client shutdown:', shutdownErr);
    }
  }
}

// Run the setup and schema verification
setupCassandra()
  .then(() => inspectSchema())
  .then(() => addMissingColumns())
  .then(() => inspectSchema()) // Check schema again after modifications
  .catch(err => console.error('Script execution failed:', err));