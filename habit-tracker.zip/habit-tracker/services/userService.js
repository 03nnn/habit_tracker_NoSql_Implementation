// services/userService.js
const User = require('../models/User'); // MongoDB model
const { cassandraClient } = require('../config/db');
const { types } = require('cassandra-driver');
const bcrypt = require('bcrypt');

module.exports = {
  createUser: async (userData) => {
    try {
      if (process.env.DB_ENGINE === 'mongodb') {
        const user = new User({
          username: userData.username,
          email: userData.email,
          password: userData.password // Already hashed in auth.js
        });
        const savedUser = await user.save();
        return savedUser._id;
      } else {
        // Cassandra flow
        const userId = types.Uuid.random();
        const client = cassandraClient(); // Get the client instance
        
        const queries = [
          {
            query: `INSERT INTO users (user_id, username, email, password, created_at) 
                    VALUES (?, ?, ?, ?, ?)`,
            params: [userId, userData.username, userData.email, userData.password, new Date()]
          },
          {
            query: `INSERT INTO users_by_email (email, user_id) 
                    VALUES (?, ?)`,
            params: [userData.email, userId]
          }
        ];

        await client.batch(queries, { prepare: true });
        return userId;
      }
    } catch (err) {
      console.error('User creation error:', err);
      throw new Error(`User creation failed: ${err.message}`);
    }
  },

  findUserByEmail: async (email) => {
    try {
      if (process.env.DB_ENGINE === 'mongodb') {
        return await User.findOne({ email });
      } else {
        const client = cassandraClient(); // Get the client instance
        
        // First find the user_id by email
        const emailResult = await client.execute(
          'SELECT user_id FROM users_by_email WHERE email = ?',
          [email],
          { prepare: true }
        );
        
        if (!emailResult.rowLength) return null;

        // Then get the full user data
        const userResult = await client.execute(
          'SELECT * FROM users WHERE user_id = ?',
          [emailResult.rows[0].user_id],
          { prepare: true }
        );

        return userResult.rowLength ? userResult.rows[0] : null;
      }
    } catch (err) {
      console.error('User lookup error:', err);
      throw new Error(`User lookup failed: ${err.message}`);
    }
  }
};