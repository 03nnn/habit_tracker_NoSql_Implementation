// services/habitService.js
const Habit = require('../models/Habit'); // MongoDB model
const { cassandraClient } = require('../config/db');
const { types } = require('cassandra-driver');

module.exports = {
  // Get Habits
  getHabits: async (userId) => {
    try {
      if (process.env.DB_ENGINE === 'mongodb') {
        return await Habit.find({ user: userId });
      } else {
        const client = cassandraClient(); // Get the client instance
        const query = 'SELECT * FROM habits WHERE user_id = ?';
        const result = await client.execute(
          query, 
          [types.Uuid.fromString(userId)], 
          { prepare: true }
        );
        
        return result.rows.map(row => ({
          id: row.habit_id.toString(),
          name: row.name,
          frequency: row.frequency || 'daily',
          created_at: row.created_at
        }));
      }
    } catch (err) {
      console.error('Get habits error:', err);
      throw new Error(`Failed to get habits: ${err.message}`);
    }
  },

  // Create Habit
  createHabit: async (userId, habitData) => {
    try {
      if (process.env.DB_ENGINE === 'mongodb') {
        const habit = new Habit({
          user: userId,
          name: habitData.name,
          frequency: habitData.frequency || 'daily'
        });
        return await habit.save();
      } else {
        const client = cassandraClient(); // Get the client instance
        const query = `
          INSERT INTO habits 
          (user_id, habit_id, name, frequency, created_at) 
          VALUES (?, ?, ?, ?, ?)
        `;
        
        const habitId = types.Uuid.random();
        await client.execute(query, [
          types.Uuid.fromString(userId),
          habitId,
          habitData.name,
          habitData.frequency || 'daily',
          new Date()
        ], { prepare: true });
        
        return habitId;
      }
    } catch (err) {
      console.error('Create habit error:', err);
      throw new Error(`Failed to create habit: ${err.message}`);
    }
  },
  
  // Update Habit
  updateHabit: async (userId, habitId, habitData) => {
    try {
      if (process.env.DB_ENGINE === 'mongodb') {
        return await Habit.findOneAndUpdate(
          { _id: habitId, user: userId },
          { $set: habitData },
          { new: true }
        );
      } else {
        const client = cassandraClient(); // Get the client instance
        const query = `
          UPDATE habits 
          SET name = ?, frequency = ? 
          WHERE user_id = ? AND habit_id = ?
        `;
        
        await client.execute(query, [
          habitData.name,
          habitData.frequency || 'daily',
          types.Uuid.fromString(userId),
          types.Uuid.fromString(habitId)
        ], { prepare: true });
      }
    } catch (err) {
      console.error('Update habit error:', err);
      throw new Error(`Failed to update habit: ${err.message}`);
    }
  },
  
  // Delete Habit
  deleteHabit: async (userId, habitId) => {
    try {
      if (process.env.DB_ENGINE === 'mongodb') {
        return await Habit.findOneAndDelete({ _id: habitId, user: userId });
      } else {
        const client = cassandraClient(); // Get the client instance
        const query = `
          DELETE FROM habits 
          WHERE user_id = ? AND habit_id = ?
        `;
        
        await client.execute(query, [
          types.Uuid.fromString(userId),
          types.Uuid.fromString(habitId)
        ], { prepare: true });
      }
    } catch (err) {
      console.error('Delete habit error:', err);
      throw new Error(`Failed to delete habit: ${err.message}`);
    }
  }
};