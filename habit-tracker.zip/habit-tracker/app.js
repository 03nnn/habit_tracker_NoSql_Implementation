// Updated app.js
const path = require('path');
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const { connectMongoDB, connectCassandra } = require('./config/db');
const app = express();

// Database connection
if (process.env.DB_ENGINE === 'mongodb') {
  connectMongoDB();
} else if (process.env.DB_ENGINE === 'cassandra') {
  connectCassandra();
} else {
  console.error('No database engine specified in .env');
  process.exit(1);
}

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || 'fallback_secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict'
  }
}));

// Routes
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/habits'));

app.get('/', (req, res) => {
  res.render('index', { 
    title: 'Habit Tracker',
    userId: req.session.userId 
  });
});

// Error handling
app.use((req, res) => res.status(404).render('error', { error: 'Page not found' }));
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { error: 'Server error' });
});

// Server start
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));