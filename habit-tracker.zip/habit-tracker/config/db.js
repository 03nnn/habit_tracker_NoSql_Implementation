const mongoose = require('mongoose');
const cassandra = require('cassandra-driver');

// MongoDB Connection
const connectMongoDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log(`MongoDB Connected: ${mongoose.connection.host}`);
  } catch (err) {
    console.error(`MongoDB Connection Error: ${err.message}`);
    process.exit(1);
  }
};

// Initialize Cassandra client
let cassandraClient = null;

// Cassandra Connection
const connectCassandra = async () => {
  try {
    cassandraClient = new cassandra.Client({
      contactPoints: process.env.CASSANDRA_CONTACT_POINTS.split(','),
      localDataCenter: process.env.CASSANDRA_DC,
      keyspace: process.env.CASSANDRA_KEYSPACE
    });
    
    await cassandraClient.connect();
    console.log('Cassandra Connected');
  } catch (err) {
    console.error(`Cassandra Connection Error: ${err.message}`);
    process.exit(1);
  }
};

module.exports = { connectMongoDB, connectCassandra, cassandraClient: () => cassandraClient };