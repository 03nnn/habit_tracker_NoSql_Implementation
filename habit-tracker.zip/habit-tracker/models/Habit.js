const mongoose = require('mongoose');

const habitSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  frequency: {
    type: String,
    enum: ['daily', 'weekly', 'monthly'],
    default: 'daily'
  },
  progress: [Date],
  streak: {
    type: Number,
    default: 0
  }
}, { timestamps: true });

habitSchema.methods.updateStreak = function() {
  const sortedDates = [...this.progress].sort((a, b) => b - a);
  let streak = 0;
  let lastDate = new Date();

  for (const date of sortedDates) {
    const diffDays = Math.floor((lastDate - date) / (1000 * 60 * 60 * 24));
    if (diffDays > 1) break;
    streak++;
    lastDate = date;
  }

  this.streak = streak;
  return this.save();
};

module.exports = mongoose.model('Habit', habitSchema);