// Updated dashboard route in routes/habits.js
const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const habitService = require('../services/habitService');

// Authentication middleware
const isAuthenticated = (req, res, next) => {
  if (req.session.userId) {
    return next();
  }
  res.redirect('/login');
};

// Dashboard Route
router.get('/dashboard', isAuthenticated, async (req, res) => {
  try {
    console.log('Loading dashboard for user ID:', req.session.userId);
    const habits = await habitService.getHabits(req.session.userId);
    
    // Format habits for display
    const formattedHabits = habits.map(habit => {
      if (process.env.DB_ENGINE === 'mongodb') {
        return {
          id: habit._id.toString(),
          name: habit.name,
          frequency: habit.frequency || 'daily',
          streak: habit.streak || 0,
          created: habit.createdAt
        };
      } else {
        return {
          id: habit.habit_id ? habit.habit_id.toString() : habit.id,
          name: habit.name,
          frequency: habit.frequency || 'daily',
          streak: habit.streak || 0,
          created: habit.created_at
        };
      }
    });
    
    res.render('dashboard', { 
      habits: formattedHabits,
      error: req.query.error || null,
      success: req.query.success || null
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    res.render('error', { error: 'Failed to load dashboard' });
  }
});

// Create Habit Route
router.post('/habits', isAuthenticated, [
  check('name').notEmpty().withMessage('Habit name is required').trim().escape(),
  check('frequency').isIn(['daily', 'weekly', 'monthly']).withMessage('Invalid frequency')
], async (req, res) => {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    return res.redirect('/dashboard?error=Invalid input');
  }
  
  try {
    console.log('Creating habit for user ID:', req.session.userId);
    await habitService.createHabit(req.session.userId, {
      name: req.body.name,
      frequency: req.body.frequency
    });
    
    res.redirect('/dashboard?success=Habit created successfully');
  } catch (err) {
    console.error('Habit creation error:', err);
    res.redirect('/dashboard?error=Failed to create habit');
  }
});

// Add other routes as needed...

module.exports = router;