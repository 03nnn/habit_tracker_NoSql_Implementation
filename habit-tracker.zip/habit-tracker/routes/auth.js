// Updated auth.js with additional error handling and debugging
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { check, validationResult } = require('express-validator');
const userService = require('../services/userService');

// Login Page
router.get('/login', (req, res) => res.render('auth/login', { error: undefined, email: '' }));

// Login Handle
router.post('/login', [
  check('email').isEmail().withMessage('Please enter a valid email').normalizeEmail(),
  check('password').exists().withMessage('Password is required').trim().escape()
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('auth/login', { 
      error: 'Invalid email or password format',
      email: req.body.email
    });
  }

  try {
    console.log('Attempting login for:', req.body.email);
    const user = await userService.findUserByEmail(req.body.email);
    
    if (!user) {
      console.log('No user found with email:', req.body.email);
      return res.render('auth/login', {
        error: 'Invalid email or password',
        email: req.body.email
      });
    }

    console.log('User found, verifying password');
    const validPassword = await bcrypt.compare(req.body.password, user.password);
    if (!validPassword) {
      console.log('Invalid password for user:', req.body.email);
      return res.render('auth/login', {
        error: 'Invalid email or password',
        email: req.body.email
      });
    }

    // Set session user ID based on database type
    if (process.env.DB_ENGINE === 'mongodb') {
      req.session.userId = user._id.toString();
    } else {
      req.session.userId = user.user_id.toString();
    }
    
    console.log('Login successful, redirecting to dashboard');
    res.redirect('/dashboard');
  } catch (err) {
    console.error('Login error:', err);
    res.render('auth/login', { 
      error: 'Server error during login. Please try again.',
      email: req.body.email
    });
  }
});

// Register Page
router.get('/register', (req, res) => res.render('auth/register', { error: undefined, errors: undefined, username: '', email: '' }));

// Register Handle
router.post('/register', [
  check('username').isLength({ min: 3 }).withMessage('Username must be at least 3 characters').trim().escape(),
  check('email').isEmail().withMessage('Please enter a valid email').normalizeEmail(),
  check('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.render('auth/register', {
      errors: errors.array(),
      username: req.body.username,
      email: req.body.email
    });
  }

  try {
    console.log('Attempting to register user:', req.body.email);
    
    // Check if user already exists
    const existingUser = await userService.findUserByEmail(req.body.email);
    if (existingUser) {
      console.log('User already exists:', req.body.email);
      return res.render('auth/register', {
        error: 'Email already registered',
        username: req.body.username,
        email: req.body.email
      });
    }

    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    
    const userId = await userService.createUser({
      username: req.body.username,
      email: req.body.email,
      password: hashedPassword
    });

    if (process.env.DB_ENGINE === 'mongodb') {
      req.session.userId = userId.toString();
    } else {
      req.session.userId = userId.toString();
    }
    
    console.log('Registration successful, redirecting to dashboard');
    res.redirect('/dashboard');
  } catch (err) {
    console.error('Registration error:', err);
    res.render('auth/register', {
      error: `Registration failed: ${err.message}`,
      username: req.body.username,
      email: req.body.email
    });
  }
});

// Logout
router.post('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;